# Custom 60% nRF52840 ZMK firmware

This is a ZMK configuration starter generated from `keyboardV2.kicad_sch`.

## Hardware read from the schematic
- Controller symbol/footprint: `SuperMini nRF52840` (`SUPERmini:SuperMini NRF52840`)
- Matrix: 5 rows x 14 columns
- 61 switch symbols and 61 1N4148W diodes
- 65 `SK6812MINI-E` RGB LEDs
- No rotary encoder symbol was found in the schematic, so no encoder behavior is configured.
- LED data net: `LEDDATA`
- Intended LED data GPIO: P1.07 (from the earlier pin mapping)

## Important validation before flashing
The schematic contains a SuperMini nRF52840 controller, but ZMK does not list a dedicated
SuperMini target. This configuration uses the `nice_nano//zmk` target as a Pro Micro-style
nRF52840 compatibility target. Confirm the exact SuperMini board revision/bootloader and
that its pinout matches the schematic before flashing. A wrong board target can prevent
booting or USB recovery.

The GPIO assignments below are the assignments previously extracted from the schematic.
Please verify them against the final KiCad netlist/PCB before applying power:

| Matrix signal | GPIO |
|---|---|
| Row0..Row4 | P0.06, P0.08, P0.17, P0.20, P0.22 |
| Col0..Col13 | P0.24, P1.00, P0.11, P1.04, P1.06, P0.31, P0.29, P0.02, P1.15, P1.13, P1.11, P0.10, P1.01, P1.02 |
| LEDDATA | P1.07 |

The matrix keymap below assumes the electrical matrix positions are laid out in conventional
60% ANSI row/column order. If the PCB's actual row/column net assignment differs, the
keymap must be remapped using the KiCad netlist before flashing. Do not assume the PCB
visual key positions automatically match matrix coordinates.

## Build
1. Create a GitHub repository and upload the contents of this folder.
2. GitHub Actions builds the firmware automatically.
3. Download `firmware` from the completed Actions run.
4. Put the controller into its bootloader and flash the resulting `.uf2` only after confirming
   the target board/bootloader compatibility.

## Key behavior
- Layer 0: normal 60% ANSI layout.
- Right Alt: hold for Layer 1 (Fn).
- Layer 1: F1-F12, navigation, media, and RGB controls.
- Exactly two layers are defined.

## RGB note
ZMK's RGB underglow subsystem supports addressable SK6812 LEDs and can be used for per-key
lighting when the LEDs are chained in the required physical order. This project configures
one 65-LED chain. It does not yet contain per-key positional effects or a per-switch LED
mapping; those require the physical LED chain order/coordinates from the PCB. The standard
ZMK effects and RGB controls operate on the full chain.
